fetch('properties.json')
  .then(response => response.json())
  .then(data => {
    const container = document.getElementById('properties');
    data.forEach(property => {
        const card = document.createElement('div');
        card.className = 'property-card';
        card.innerHTML = `
            <img src="\${property.image}" alt="Property image">
            <h2>\${property.title}</h2>
            <p><strong>Price:</strong> \${property.price}</p>
            <p><strong>Location:</strong> \${property.location}</p>
            <p>\${property.description}</p>
        `;
        container.appendChild(card);
    });
  });